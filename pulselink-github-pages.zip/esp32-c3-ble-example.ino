/*
  ESP32-C3 BLE notification example for the PulseLink website.

  Replace the demo values with readings calculated from your MAX30102 library.
  The website expects JSON:
  {"spo2":98,"bpm":76,"battery":87}
*/

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

#define SERVICE_UUID "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define NOTIFY_UUID  "6e400003-b5a3-f393-e0a9-e50e24dcca9e"

BLECharacteristic *notifyCharacteristic;
bool deviceConnected = false;

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *server) {
    deviceConnected = true;
  }

  void onDisconnect(BLEServer *server) {
    deviceConnected = false;
    BLEDevice::startAdvertising();
  }
};

void setup() {
  Serial.begin(115200);

  BLEDevice::init("Oximeter-C3");
  BLEServer *server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());

  BLEService *service = server->createService(SERVICE_UUID);
  notifyCharacteristic = service->createCharacteristic(
    NOTIFY_UUID,
    BLECharacteristic::PROPERTY_NOTIFY
  );
  notifyCharacteristic->addDescriptor(new BLE2902());

  service->start();

  BLEAdvertising *advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->setScanResponse(true);
  advertising->start();

  Serial.println("Oximeter BLE ready");
}

void loop() {
  static unsigned long lastSend = 0;

  if (!deviceConnected || millis() - lastSend < 1000) {
    return;
  }

  lastSend = millis();

  int spo2 = 98;     // Replace with MAX30102 SpO2 result.
  int bpm = 76;      // Replace with MAX30102 heart-rate result.
  int battery = 87;  // Replace with battery percentage calculation.

  String payload = "{\"spo2\":" + String(spo2) +
                   ",\"bpm\":" + String(bpm) +
                   ",\"battery\":" + String(battery) + "}";

  notifyCharacteristic->setValue(payload.c_str());
  notifyCharacteristic->notify();
  Serial.println(payload);
}
